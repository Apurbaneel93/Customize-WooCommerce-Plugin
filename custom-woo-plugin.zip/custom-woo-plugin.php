<?php
/*
Plugin Name: Customize WooCommerce Plugin
Description: Assignment Test Plugin
Version: 1.0
Author: Apurba Nath
Icon:
*/

function extend_woo_feature_menu() {
    add_menu_page(
        'Assignment Test Plugin',
        'Extend Woo Feature',
        'manage_options',
        'extend_woo_feature',
        'extend_woo_feature_page'
    );
}
add_action('admin_menu', 'extend_woo_feature_menu');

// Display the settings page
function extend_woo_feature_page() {
    ?>
    <div class="wrap">
        <h2>Extend Woo Feature</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_text_field_settings');
            do_settings_sections('custom_text_field_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register and initialize the settings
function custom_text_field_settings() {
    register_setting('custom_text_field_settings', 'custom_text_field_option');
    add_settings_section('custom_text_field_section', 'Additional Price Settings', 'custom_text_field_section_callback', 'custom_text_field_settings');
    add_settings_field('custom_text_field_option', 'Enter Additional Fee(₹):', 'custom_text_field_option_callback', 'custom_text_field_settings', 'custom_text_field_section');
}
add_action('admin_init', 'custom_text_field_settings');

// Section callback
function custom_text_field_section_callback() {
    //echo 'Enter your custom text below:';
}


function custom_text_field_option_callback() {
    $value = get_option('custom_text_field_option');
    echo '<input type="text" name="custom_text_field_option" value="' . esc_attr($value) . '" />';
}

function custom_add_fee() {
    $fee = get_option('custom_text_field_option');
    WC()->cart->add_fee('Additional Fee', $fee, true, 'standard');
}
add_action('woocommerce_cart_calculate_fees', 'custom_add_fee');


// add_action('woocommerce_product_options_general_product_data', 'woocommerce_product_custom_fields');
// function woocommerce_product_custom_fields()
// {
//     global $woocommerce, $post;
//     echo '<div class="product_custom_field">';
//     woocommerce_wp_text_input(
//         array(
//             'id' => '_custom_product_additional_fee',
//             'placeholder' => 'Add Additional Fee',
//             'label' => __('Additional Fee (₹)', 'woocommerce'),
//             'desc_tip' => 'true'
//         )
//     );
//     echo '</div>';
// }

// add_action('woocommerce_process_product_meta', 'woocommerce_product_custom_fields_save');
// function woocommerce_product_custom_fields_save($post_id)
// {
//     $woocommerce_custom_product_additional_fee = $_POST['_custom_product_additional_fee'];
//     if (!empty($woocommerce_custom_product_additional_fee))
//         update_post_meta($post_id, '_custom_product_additional_fee', esc_attr($woocommerce_custom_product_additional_fee));
// }


// function get_product_custom_field_value($product_id, $custom_field_name) {
//     $custom_field_value = get_post_meta($product_id, $custom_field_name, true);
//     return $custom_field_value;
// }

// function custom_add_fee() {
//     $product_id = 14;
//     $fee = get_product_custom_field_value($product_id, '_custom_product_additional_fee');
//     WC()->cart->add_fee('Additional Fee', $fee, true, 'standard');
// }
// add_action('woocommerce_cart_calculate_fees', 'custom_add_fee');








// Customer add Custom field on product page
function display_custom_textarea_on_product_page() {
    ?>
    <div>
        <label for="custom_textarea">Special Requirement</label>
        <textarea id="custom_textarea" name="custom_textarea"></textarea>
    </div>
    <?php
}
add_action('woocommerce_after_add_to_cart_button', 'display_custom_textarea_on_product_page');
function add_custom_textarea_js() {
    ?>
    <script>
        jQuery(document).ready(function($) {
            $('form.cart').on('submit', function() {
                var customTextareaValue = $('#custom_textarea').val();
                $('<input>').attr({
                    type: 'hidden',
                    name: 'custom_textarea',
                    value: customTextareaValue
                }).appendTo('form.cart');
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'add_custom_textarea_js');


function save_custom_textarea_value_to_cart_item($cart_item_data, $product_id) {
    if (isset($_POST['custom_textarea'])) {
        $cart_item_data['custom_textarea'] = sanitize_textarea_field($_POST['custom_textarea']);
    }
    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'save_custom_textarea_value_to_cart_item', 10, 2);

function display_custom_textarea_in_cart_item($item_data, $cart_item) {
    if (!empty($cart_item['custom_textarea'])) {
        $item_data[] = array(
            'key'     => __('Special Requirement', 'text-domain'),
            'value'   => wc_clean($cart_item['custom_textarea']),
            'display' => '',
        );
    }
    return $item_data;
}
add_filter('woocommerce_get_item_data', 'display_custom_textarea_in_cart_item', 10, 2);

function save_custom_order_item_metadata( $item, $cart_item_key, $values, $order ) {
        if ( isset($values['custom_textarea']) && ! empty($values['custom_textarea']) ) {
            $item->add_meta_data('Special Requirement', $values['custom_textarea'] );
        }
}
add_action('woocommerce_checkout_create_order_line_item', 'save_custom_order_item_metadata', 10, 4 );
?>